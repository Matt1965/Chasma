// src/props/vegetation/mod.rs

pub mod rules;
pub mod systems;
pub mod plugin;
pub mod sampler;